<?php

require_once(get_template_directory() . '/post-type/brand.php');

/**
 * 
 * @ Thiết lập các hằng dữ liệu quan trọng
 * @ THEME_URL = get_stylesheet_directory() – đường dẫn tới thư mục theme
 * @ CORE = thư mục /core của theme, chứa các file nguồn quan trọng.
 * 
 */
define('THEME_URL', get_stylesheet_directory());

add_theme_support('post-thumbnails');
add_post_type_support('brands', 'thumbnails');

function add_css()
{
    // wp_enqueue_style('bootstrap', get_template_directory_uri() . '/static/css/bootstrap.min.css', 'all');
    wp_enqueue_style('base-style', get_template_directory_uri() . '/static/css/base.css', 'all');
    wp_enqueue_style('main-style', get_template_directory_uri() . '/static/css/style.css', 'all');
    // wp_enqueue_style('main-style');
}
add_action('wp_enqueue_scripts', 'add_css');

function add_scripts()
{
    wp_enqueue_script('jquery', get_template_directory_uri() . '/static/js/jquery.min.js', array('jquery'), '1.0', true);
    // wp_enqueue_script('bootstrap', get_template_directory_uri() . '/static/js/bootstrap.min.js', array('jquery'), '1.0', true);
    // wp_enqueue_script('search', get_template_directory_uri() . '/static/js/search.js', array('jquery'), '1.0', true);
    wp_enqueue_script('app-js', get_template_directory_uri() . '/static/js/app.js', array('jquery'), '1.0', true);
    wp_enqueue_script('main-js', get_template_directory_uri() . '/static/js/main.js', array('jquery'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'add_scripts');

function my_custom_scripts()
{
    wp_enqueue_script('my-custom-script', get_template_directory_uri() . '/static/js/search.js', array('jquery'));

    $custom_data = array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
    );
    wp_localize_script('my-custom-script', 'wpAjax', $custom_data);
}
add_action('wp_enqueue_scripts', 'my_custom_scripts');

function register_my_menu()
{
    register_nav_menu('main-menu', __('Main Menu'));
}
add_action('init', 'register_my_menu');

function filter()
{
    $category = $_POST['category'];
    parse_str($category, $data_parsed);
    $s = $data_parsed['s'];
    $taxonomy = 'brand_cat';
    $categories = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => true]);

    foreach ($categories as $category) {
        $category_slug = $category->slug;
        $category_name = $category->name;

        echo '<pre>';
        print_r($categories); // Trả về Array
        echo '</pre>';

        echo '<pre>';
        print_r($category); //$category_slug trả về index[0]
        echo '</pre>';

        $args = array(
            'post_type' => 'brand',
            'posts_per_page' => -1,
            's' => $s,
            'tax_query' => [
                'taxonomy' => 'brand_cat',
                'field' => 'slug',
                'terms' => $category_slug,
            ],
        );

        // var_dump($args);

        // echo '<pre>';
        // print_r($args);
        // echo '</pre>';

        if ($s) {
            $args['s'] = $s;
        };

        $brands = new WP_Query($args);
?>
        <?php if ($s) : ?>
            <div id="<?php echo $category_slug ?>" class="brand-container">
                <h2 class="main-title"><?php echo $category_name ?></h2>

                <div class="brand-grid js-brands">
                    <?php if ($brands->have_posts()) :
                        while ($brands->have_posts()) : $brands->the_post();
                            get_template_part('template-parts/cards/brand');
                        endwhile;
                    endif; ?>
                </div>
            </div>
        <?php endif; ?>

<?php
        wp_reset_postdata();

        die();
    }
}
add_action('wp_ajax_filter', 'filter');
add_action('wp_ajax_nopriv_filter', 'filter');
