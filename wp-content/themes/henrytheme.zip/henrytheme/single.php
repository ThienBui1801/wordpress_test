<?php
get_header();
?>

<?php
get_template_part('template-parts/banner-page/banner');
?>

<?php
get_footer();
?>