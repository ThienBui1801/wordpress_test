jQuery(document).ready(function ($) {
   const form = $('.form-filter');

   form.submit(function (e) {
      e.preventDefault();
      call_ajax(form.serialize());
      console.log(form.serialize())
   })

   function call_ajax(args) {
      console.log(wpAjax.ajaxUrl);
      $.ajax({
         type: 'POST',
         url: wpAjax.ajaxUrl,
         data: {
            action: 'filter',
            category: args,
            // s: args.s,
         },
         success: function (res) {
            // console.log(res);
            $('.js-render').html(res);
         },
         error: function (res) {
            // Xử lý lỗi (nếu có)
            console.warn(res)
         }
      });
   }
});

