'use strict';

function openNavMenu() {
   const btnNav = document.getElementById('btnNav');
   const nav = document.getElementById('navMobile');

   function closeModal() {
      nav.classList.remove('openNav')
   };

   btnNav.addEventListener('click', () => {
      nav.classList.toggle('openNav');
   });

   document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
         closeModal()
      }
   })
}

document.addEventListener('DOMContentLoaded', function () {
   openNavMenu();
});

