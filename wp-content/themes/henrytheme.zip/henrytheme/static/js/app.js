// (function ($) {
//    $(document).ready(function () {
//       
//    })
// })(jQuery);

jQuery(document).ready(function ($) {
   $('.menu-item').each(function () {
      $(this).click(function (e) {
         e.preventDefault();
         if (!$(this).hasClass('is-active')) {
            $(this).addClass('is-active');
            $(this).children('.sub-menu').slideDown();
         } else {
            $(this).removeClass('is-active');
            $(this).children('.sub-menu').slideUp();
         }
      })
   });
});