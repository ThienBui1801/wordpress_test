<?php
$base_url = get_template_directory_uri();
$banner = $base_url . '/static/images/directory-top-banners.jpg';
?>

<section>
	<div style="background-image: url(<?php echo $banner ?>);" class="banner-page">

	</div>
</section>