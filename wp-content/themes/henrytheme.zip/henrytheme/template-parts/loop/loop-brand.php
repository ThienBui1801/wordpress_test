<div class="brand-item">
   <?php if (has_post_thumbnail()) : ?>
      <picture>
         <img src="<?php the_post_thumbnail_url() ?>" alt="<?php the_title() ?>">
      </picture>
   <?php endif; ?>

   <h4><?php echo the_title() ?></h4>

   <?php
   $cats = get_the_terms(get_the_ID(), 'brand');
   ?>
</div>