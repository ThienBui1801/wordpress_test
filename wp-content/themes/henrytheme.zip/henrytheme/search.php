<?php get_header();
global $wp_query;
$wp_query->set('is_search', true);
echo '<div class="pt-[100px]"></div>';
lw_view(ABSPATH . '/static/components/contents/ketquatimkiem.php', [
	'base_url' => LW_SITE_URL . '/static/',
	'titleSearch' => sprintf(__('Kết quả tìm kiếm cho “ %s”:', 'letweb'), get_search_query()),
]);
$current_post_type = isset($_GET['post_type']) ? $_GET['post_type'] : 'post';
$post_types = [
	'product' => __('Sản phẩm', 'letweb'),
	'post' => __('Bài viết', 'letweb'),
]
?>
<div class="grid lg:grid-cols-12 container py-[30px]">
    <div class="py-[60px] lg:border-y-[0.5px] border-gray-5 border-opacity-50 lg:col-span-3">
    	<?php foreach ($post_types as $post_type => $label) {
    		$css_class = 'font-heading lg:text-28 text-24 leading-[32px] tracking-normal lg:pl-0 pl-4 hover:text-primary transition-all duration-300';
			if ($current_post_type == $post_type) {
				$css_class .= ' text-primary';
			} else {
				$css_class .= ' text-gray-5';
			} 
    		$search_link = add_query_arg([
				's' => get_query_var('s'),
				'post_type' => $post_type,
			]);
    	?>
        <div class="pt-4">
		    <a href="<?php echo $search_link ?>" class="<?php echo $css_class ?>">
		        <?php echo $label ?>
		    </a>
		</div>
		<?php } ?>
    </div>
    <div class="lg:py-[60px] py-[30px] lg:col-span-9 border-y-[0.5px] border-gray-5 border-opacity-50">
        <div class="pb-10 flex flex-col items-center">
        	<?php
				$post_type = $_GET['post_type'];
				$card = ($post_type == 'product') ? 'cards/card-product' : 'cards/card-news';
				$args = [
					'posts_per_page' => 6,
					'tax_query' => []
				];
				$collection = lw_get_post_type_collection($current_post_type);
				$collection->args($args);
				$post_list_component = new \Letweb\Template\PostListComponent();
				$post_list_component->setBasePath(lw_get_path('template-parts/'));
				$post_list_component->setCollection($collection);
				$post_list_component->setTemplate('grid/grid-search');
				$post_list_component->setLoop('loop/loop');
				$post_list_component->setLoopItem($card);
				$post_list_component->setParam('posts_per_page', $args['posts_per_page']);
				$post_list_component->setPaginationType(\Letweb\Template\PostListComponent::PAGINATION_TYPE_NUMERIC);
				$post_list_component->render();
			?>
        </div>
    </div>
</div>
<?php get_footer('noform'); ?>